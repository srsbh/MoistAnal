# MoistAnal
Optimal moisuture experiments on termites to see building behaviour analysis codes
